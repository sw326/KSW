package board.mvc.control;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import mvc.domain.Board;

import java.io.IOException;
import java.util.ArrayList;

import board.mvc.model.BrdService;

/**
 * Servlet implementation class BoardController
 */
@WebServlet("/board/brd.do")
public class BoardController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void service(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		String m = request.getParameter("m");
		System.out.println(m);
		if(m != null) {
			m = m.trim();
			switch(m) {
			case "input": input(request, response); break;
			case "insert": insert(request, response); break;
			//case "getBoard": getBoard(request, response); break;
			case "del": del(request, response); break;
			}
		}else {
			list(request, response);
		}
	}
	
	private void list(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException {
		
		BrdService service = BrdService.getInstance();
		ArrayList<Board> list = service.listS();
		request.setAttribute("list", list);
		
		String view = "list.jsp";
		RequestDispatcher rd = request.getRequestDispatcher(view);
		rd.forward(request, response);
	}
	
	private void input(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.sendRedirect("input.jsp");
	}
	
	private void insert(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String writer = request.getParameter("writer");
		String email = request.getParameter("email");
		String subject = request.getParameter("subject");
		String content = request.getParameter("content");
		Board board = new Board(-1L, writer, email, subject, content, null);
		
		BrdService service = BrdService.getInstance();
		boolean flag = service.insertS(board);
		request.setAttribute("flag", flag);
		
		String view = "msg.jsp";
		RequestDispatcher rd = request.getRequestDispatcher(view);
		rd.forward(request, response);
	}
	
//	private void getBoard(HttpServletRequest request, HttpServletResponse response)
//			throws ServletException, IOException {
//		BrdService service = BrdService.getInstance();
//		long seq = Long.parseLong(request.getParameter("seq"));
//		Board board = service.getBoardS(seq);
//		request.setAttribute("board", board);
//		
//		String view = "content.jsp";
//		RequestDispatcher rd = request.getRequestDispatcher(view);
//		rd.forward(request, response);
//	}
	
	private void del(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
	}
}













