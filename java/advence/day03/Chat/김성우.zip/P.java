class P{
	void p(String str){
		System.out.print(str);
	}
	void pln(String str){
		System.out.println(str);
	}
}
