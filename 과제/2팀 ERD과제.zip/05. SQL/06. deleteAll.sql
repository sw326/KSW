delete from BOOKS;
delete from PAYMENT_METHODS;
delete from AGE_RATINGS;
delete from DELIVERY_ADDRESSES;
delete from CHILDREN;
delete from CART_ITEMS;
delete from ORDERS;
delete from CATEGORIES;
delete from ADDRESSES;
delete from MEMBER;
delete from MEMBER_TYPE;

commit;
