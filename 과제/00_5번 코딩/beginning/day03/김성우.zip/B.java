class B1
{
	int i = 1;
	final int J = 2; // 상수(불변값)
	void m(){
		i = 10;
		// J = 20;
}


class B2
{
	int i = 1;
	final int J = 2; // 상수
	void m(){
		i = 10;
		// J = 20;
	}
}

class B3
{
	int i = 1;
	final int J = 2;
	void m() {
		i = 10;
		// J = 20;
	}
}


class B3
{
	int i = 1;
	final int J = 2;
	void m(){
		i = 10;
		// J = 20;
	}
}

class B4
{
	int i = 1;
	final int J = 2;
	void m(){
		i = 10;
		// J = 20;
}

class B5
{
	int i = 10;
	final int J = 20;
	void m(){
		i = 10;
		// J = 20;
}