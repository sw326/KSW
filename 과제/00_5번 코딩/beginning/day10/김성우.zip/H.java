class H
{
	int $_i;
}

class H1 int $_i;