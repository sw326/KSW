public class B
{
}
/*
public class BTest //안됨
{
}
*/

public class B1{}

// public class BTest{}