package a.b;

public class A {
	private int i;
	private A(){
		System.out.println("A()");
	}
	private void m(){
		System.out.println("m()");
	}
}

public class A1
{
	private int i;
	private A1(){
		System.out.println("A()");
	}
	private void m(){
		System.out.println("m()");
	}
}