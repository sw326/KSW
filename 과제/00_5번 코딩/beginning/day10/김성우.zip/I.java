class I {
	class IInner{
	}
}

class I1{
	class IInner
}